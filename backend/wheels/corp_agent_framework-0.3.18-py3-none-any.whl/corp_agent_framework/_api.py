"""
HTTP client for corp-agent-framework — reads agent/tool config from corp-client-agent API.

Required env var:
  CORP_CLIENT_AGENT_URL    — base URL of the corp-client-agent app
                             e.g. https://corp-client-agent-xxx.aws.databricksapps.com

Optional env var:
  CORP_CLIENT_AGENT_TOKEN  — Bearer token (must match CORP_CONFIG_TOKEN on the server)
"""

import os

import requests


def _base_url() -> str:
    url = os.environ.get("CORP_CLIENT_AGENT_URL", "").rstrip("/")
    if not url:
        raise RuntimeError(
            "CORP_CLIENT_AGENT_URL environment variable not set. "
            "Set it to the URL of the corp-client-agent app."
        )
    return url


def _headers() -> dict:
    token = os.environ.get("CORP_CLIENT_AGENT_TOKEN", "")
    return {"Authorization": f"Bearer {token}"} if token else {}


def get_agent(domain: str, agent_id: str, environment: str | None = None) -> dict | None:
    """Fetch a single agent config row. Returns None if not found (404)."""
    params: dict = {}
    if environment:
        params["environment"] = environment

    resp = requests.get(
        f"{_base_url()}/api/config/agents/{domain}/{agent_id}",
        headers=_headers(),
        params=params,
        timeout=30,
    )
    if resp.status_code == 404:
        return None
    resp.raise_for_status()
    return resp.json()


def get_guardrails(domain: str) -> list[dict]:
    """Fetch active guardrails defaults for the domain. Returns empty list on any error."""
    resp = requests.get(
        f"{_base_url()}/api/config/guardrails/{domain}",
        headers=_headers(),
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json().get("guardrails", [])


def get_tools(domain: str, tool_names: list[str], environment: str | None = None) -> list[dict]:
    """Fetch tool specs for the given names. Returns list of {tool_name, kind, ref, description}."""
    if not tool_names:
        return []

    params: dict = {"names": ",".join(tool_names)}
    if environment:
        params["environment"] = environment

    resp = requests.get(
        f"{_base_url()}/api/config/tools/{domain}",
        headers=_headers(),
        params=params,
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json().get("tools", [])
