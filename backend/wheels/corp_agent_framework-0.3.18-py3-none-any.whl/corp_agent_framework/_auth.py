"""
Shared authentication helper for the corp-agent-framework.

Builds a WorkspaceClient for the DOMAIN workspace (Genie, Vector Search, UC functions).

Environment variables used by this module:
  DATABRICKS_HOST   — domain workspace URL (Genie, VS, UC functions)
  DATABRICKS_TOKEN  — domain workspace PAT

Lakebase credentials (LAKEBASE_CLIENT_ID/SECRET) are used ONLY by _pg.py and are never
read here, avoiding the Databricks SDK "more than one authorization method" conflict.

If DATABRICKS_HOST/TOKEN are not set, falls back to the default SDK auth chain.
"""

import os

from databricks.sdk import WorkspaceClient


def _build_workspace_client() -> WorkspaceClient:
    host = os.environ.get("DATABRICKS_HOST")
    token = os.environ.get("DATABRICKS_TOKEN")

    if host and token:
        from databricks.sdk.core import Config
        return WorkspaceClient(config=Config(host=host, token=token, auth_type="pat"))

    return WorkspaceClient()
