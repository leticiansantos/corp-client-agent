"""
Lakebase (PostgreSQL) connection for corp-agent-framework serving endpoints.

Reads config from environment variables:
  LAKEBASE_HOST        — PostgreSQL endpoint DNS
  LAKEBASE_DATABASE    — database name (default: databricks_postgres)
  LAKEBASE_USERNAME    — PostgreSQL role name (user email or SP UUID)

OAuth token for PostgreSQL password (checked in order):
  1. LAKEBASE_CLIENT_ID + LAKEBASE_CLIENT_SECRET + LAKEBASE_DATABRICKS_HOST  — M2M OAuth (local dev)
  2. DATABRICKS_CLIENT_ID + DATABRICKS_CLIENT_SECRET + LAKEBASE_DATABRICKS_HOST (or DATABRICKS_HOST)
     — M2M OAuth (serving endpoints; LAKEBASE_DATABRICKS_HOST targets stable workspace)
  3. DATABRICKS_TOKEN  — PAT used directly as password

LAKEBASE_CLIENT_ID/SECRET are dedicated Lakebase credentials that avoid conflicts with
DATABRICKS_CLIENT_ID/SECRET used by _auth.py for the domain workspace WorkspaceClient.

execute() — psycopg TCP connection.
"""
import os
import time

_token: str = ""
_token_expiry: float = 0.0


def _refresh_token() -> None:
    global _token, _token_expiry
    import requests

    # Priority 1: LAKEBASE_CLIENT_ID/SECRET — dedicated Lakebase SP credentials (local dev)
    lakebase_host   = (os.environ.get("LAKEBASE_DATABRICKS_HOST") or "").rstrip("/")
    lakebase_id     = os.environ.get("LAKEBASE_CLIENT_ID") or ""
    lakebase_secret = os.environ.get("LAKEBASE_CLIENT_SECRET") or ""

    if lakebase_id and lakebase_secret and lakebase_host:
        resp = requests.post(
            f"{lakebase_host}/oidc/v1/token",
            data={
                "grant_type":    "client_credentials",
                "scope":         "all-apis",
                "client_id":     lakebase_id,
                "client_secret": lakebase_secret,
            },
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        _token = data["access_token"]
        _token_expiry = time.time() + data.get("expires_in", 3600) - 300
        return

    # Priority 2: DATABRICKS_CLIENT_ID/SECRET — serving endpoint SP credentials
    # LAKEBASE_DATABRICKS_HOST targets the stable workspace where Lakebase lives.
    host          = (os.environ.get("LAKEBASE_DATABRICKS_HOST") or os.environ.get("DATABRICKS_HOST") or "").rstrip("/")
    client_id     = os.environ.get("DATABRICKS_CLIENT_ID") or ""
    client_secret = os.environ.get("DATABRICKS_CLIENT_SECRET") or ""

    if client_id and client_secret and host:
        resp = requests.post(
            f"{host}/oidc/v1/token",
            data={
                "grant_type":    "client_credentials",
                "scope":         "all-apis",
                "client_id":     client_id,
                "client_secret": client_secret,
            },
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        _token = data["access_token"]
        _token_expiry = time.time() + data.get("expires_in", 3600) - 300
        return

    # Priority 3: PAT used directly as password
    pat = os.environ.get("DATABRICKS_TOKEN") or ""
    if pat:
        _token = pat
        _token_expiry = time.time() + 86400
        return

    raise RuntimeError(
        "No credentials configured for Lakebase. Set one of:\n"
        "  LAKEBASE_CLIENT_ID + LAKEBASE_CLIENT_SECRET + LAKEBASE_DATABRICKS_HOST\n"
        "  DATABRICKS_CLIENT_ID + DATABRICKS_CLIENT_SECRET + LAKEBASE_DATABRICKS_HOST\n"
        "  DATABRICKS_TOKEN (PAT)"
    )


def _ensure_token() -> str:
    if not _token or time.time() >= _token_expiry:
        _refresh_token()
    return _token


# ── PostgREST (HTTP Data API) ─────────────────────────────────────────────────

def pg_get(
    schema: str,
    table: str,
    select: str | None = None,
    **filters: str,
) -> list[dict]:
    """PostgREST GET — preferred read path when LAKEBASE_API is set.

    URL: GET {LAKEBASE_API}/{schema}/{table}?{filters}

    Filters use PostgREST operator syntax:
      field="eq.value"        → WHERE field = 'value'
      field="in.(v1,v2,v3)"  → WHERE field IN ('v1','v2','v3')
      field="neq.value"       → WHERE field != 'value'
      field="is.null"         → WHERE field IS NULL

    Args:
        schema:   PostgreSQL schema name (e.g. "app" or a domain slug)
        table:    table name within the schema
        select:   comma-separated column list (e.g. "tool_name,kind,ref")
        **filters: PostgREST filter expressions keyed by column name
    """
    import requests as _req

    api_url = os.environ.get("LAKEBASE_API", "").rstrip("/")
    token   = _ensure_token()

    params: dict = dict(filters)
    if select:
        params["select"] = select

    resp = _req.get(
        f"{api_url}/{schema}/{table}",
        headers={
            "Authorization": f"Bearer {token}",
            "Accept":        "application/json",
        },
        params=params,
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()


# ── psycopg fallback ──────────────────────────────────────────────────────────

def get_connection():
    import psycopg
    from psycopg.rows import dict_row

    host     = os.environ.get("LAKEBASE_HOST") or ""
    dbname   = os.environ.get("LAKEBASE_DATABASE") or "databricks_postgres"
    # Username must match the SP UUID that generated the OAuth token.
    # Priority: LAKEBASE_CLIENT_ID (same SP used for token) → DATABRICKS_CLIENT_ID → LAKEBASE_USERNAME
    username = (os.environ.get("LAKEBASE_CLIENT_ID")
                or os.environ.get("DATABRICKS_CLIENT_ID")
                or os.environ.get("LAKEBASE_USERNAME")
                or "")

    if not host:
        raise RuntimeError("LAKEBASE_HOST environment variable not set.")
    if not username:
        raise RuntimeError(
            "PostgreSQL username not set. Set LAKEBASE_CLIENT_ID (SP UUID used for Lakebase OAuth)."
        )

    return psycopg.connect(
        host=host,
        dbname=dbname,
        user=username,
        password=_ensure_token(),
        sslmode="require",
        row_factory=dict_row,
    )


def _execute_via_psycopg(sql: str, params: tuple = ()) -> list[dict]:
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            return cur.fetchall() if cur.description else []


# ── Public API ────────────────────────────────────────────────────────────────

def execute(sql: str, params: tuple = ()) -> list[dict]:
    """Execute a SQL query via psycopg and return a list of row dicts.

    For simple reads, prefer pg_get() when LAKEBASE_API is set — it uses
    the PostgREST HTTP interface and requires no TCP connection.
    Use execute() for writes (INSERT/UPDATE/DELETE) and complex queries.
    """
    return _execute_via_psycopg(sql, params)


def execute_one(sql: str, params: tuple = ()) -> dict | None:
    rows = execute(sql, params)
    return rows[0] if rows else None
