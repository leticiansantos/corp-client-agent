from typing import Iterator

import mlflow
from mlflow.pyfunc import ResponsesAgent
from mlflow.types.responses import (
    ResponsesAgentRequest,
    ResponsesAgentResponse,
    ResponsesAgentStreamEvent,
    ResponseCompletedEvent,
)


class _NoopSpan:
    """Null-object span used when MLflow tracing is unavailable (e.g., during log_model)."""
    def set_inputs(self, *args, **kwargs): pass
    def set_outputs(self, *args, **kwargs): pass


class _SafeSpan:
    """
    Context manager that starts an MLflow span and falls back to a no-op when
    tracing is disabled (e.g., mlflow.pyfunc.log_model calls predict internally).

    Using a class-based context manager avoids @contextmanager generator edge-cases
    where an AttributeError thrown from the body would interact with the except clause
    that catches the AttributeError from start_span.__enter__.
    """

    def __init__(self, name: str, span_type: str):
        self._name = name
        self._span_type = span_type
        self._cm = None

    def __enter__(self):
        try:
            self._cm = mlflow.start_span(name=self._name, span_type=self._span_type)
            return self._cm.__enter__()
        except AttributeError:
            self._cm = None
            return _NoopSpan()

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._cm is not None:
            return self._cm.__exit__(exc_type, exc_val, exc_tb)
        return False  # Do not suppress exceptions when running in noop mode


class CorpAgent(ResponsesAgent):
    """
    Base class for corporate agents built as MLflow ResponsesAgents.
    Provides a single entrypoint (predict) and a hook (_run_agent) for subclasses.
    Every call is automatically traced via MLflow Tracing.
    """

    def __init__(self, name: str):
        super().__init__()
        self.name = name

    @mlflow.trace(span_type="AGENT")
    def predict(self, request: ResponsesAgentRequest) -> ResponsesAgentResponse:
        # @mlflow.trace creates a root trace when there is no active trace,
        # or a child span when the serving loader already opened one.
        # Either way, every predict() call is recorded in MLFLOW_EXPERIMENT_NAME.
        return self._run_agent(request)

    def predict_stream(
        self, request: ResponsesAgentRequest
    ) -> Iterator[ResponsesAgentStreamEvent]:
        """Non-streaming agents return the full response as a single completion event."""
        response = self.predict(request)
        yield ResponseCompletedEvent(response=response)

    def _run_agent(self, request: ResponsesAgentRequest) -> ResponsesAgentResponse:
        raise NotImplementedError("Subclasses must implement _run_agent()")
