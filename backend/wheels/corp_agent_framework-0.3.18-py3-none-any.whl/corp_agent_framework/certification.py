"""
Certification module   defines the Sandbox → Corporate promotion flow.

Tiers:
  sandbox       → Citizen developer created. Limited to dev, 50 req/day, all calls audited.
  under_review  → Submitted for Platform Engineering review. Staging allowed, 100 req/day.
  corporate     → Approved by Platform Engineering. Full production access, unlimited.
  deprecated    → Retired agent.
"""

from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timezone
from typing import Optional


class AgentTier(str, Enum):
    SANDBOX = "sandbox"
    UNDER_REVIEW = "under_review"
    CORPORATE = "corporate"
    DEPRECATED = "deprecated"


@dataclass
class CertificationPolicy:
    """Runtime restrictions enforced for each agent tier."""
    max_requests_per_day: Optional[int]   # None = unlimited
    allowed_environments: list[str]
    audit_all_calls: bool
    requires_platform_approval: bool


TIER_POLICIES: dict[AgentTier, CertificationPolicy] = {
    AgentTier.SANDBOX: CertificationPolicy(
        max_requests_per_day=50,
        allowed_environments=["dev"],
        audit_all_calls=True,
        requires_platform_approval=False,
    ),
    AgentTier.UNDER_REVIEW: CertificationPolicy(
        max_requests_per_day=100,
        allowed_environments=["dev", "staging"],
        audit_all_calls=True,
        requires_platform_approval=False,
    ),
    AgentTier.CORPORATE: CertificationPolicy(
        max_requests_per_day=None,
        allowed_environments=["dev", "staging", "prod"],
        audit_all_calls=False,
        requires_platform_approval=False,
    ),
    AgentTier.DEPRECATED: CertificationPolicy(
        max_requests_per_day=0,
        allowed_environments=[],
        audit_all_calls=True,
        requires_platform_approval=True,
    ),
}


@dataclass
class CertificationRecord:
    """Tracks the certification history of an agent."""
    agent_id: str
    current_tier: AgentTier
    submitted_by: str
    reviewed_by: Optional[str] = None
    submitted_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    reviewed_at: Optional[datetime] = None
    review_notes: Optional[str] = None
    eval_run_id: Optional[str] = None       # MLflow run ID from last eval
    eval_passed: Optional[bool] = None


def check_access(
    tier: AgentTier,
    environment: str,
    requests_today: int = 0,
) -> tuple[bool, str]:
    """
    Check whether an agent with the given tier is allowed to run.

    Returns (allowed: bool, reason: str).
    """
    policy = TIER_POLICIES[tier]

    if tier == AgentTier.DEPRECATED:
        return False, "Agent is deprecated and cannot be invoked."

    if environment not in policy.allowed_environments:
        return False, (
            f"Tier '{tier}' is not allowed in environment '{environment}'. "
            f"Allowed: {policy.allowed_environments}."
        )

    if policy.max_requests_per_day is not None and requests_today >= policy.max_requests_per_day:
        return False, (
            f"Daily request limit reached ({policy.max_requests_per_day}) for tier '{tier}'."
        )

    return True, "Access granted."


def promote(record: CertificationRecord, reviewed_by: str, notes: str = "") -> CertificationRecord:
    """
    Advance an agent to the next tier.
    Only Platform Engineering should call this in production.
    """
    transitions = {
        AgentTier.SANDBOX: AgentTier.UNDER_REVIEW,
        AgentTier.UNDER_REVIEW: AgentTier.CORPORATE,
    }
    if record.current_tier not in transitions:
        raise ValueError(f"Cannot promote from tier '{record.current_tier}'.")

    record.current_tier = transitions[record.current_tier]
    record.reviewed_by = reviewed_by
    record.reviewed_at = datetime.now(timezone.utc)
    record.review_notes = notes
    return record


def deprecate(record: CertificationRecord, reviewed_by: str, notes: str = "") -> CertificationRecord:
    """Mark an agent as deprecated."""
    record.current_tier = AgentTier.DEPRECATED
    record.reviewed_by = reviewed_by
    record.reviewed_at = datetime.now(timezone.utc)
    record.review_notes = notes
    return record
