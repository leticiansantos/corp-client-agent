from ._auth import _build_workspace_client
from . import _api


class AgentConfigLoader:
    """
    Loads agent configuration from corp-client-agent HTTP API.
    Requires CORP_CLIENT_AGENT_URL env var set to the app's base URL.
    """

    def __init__(
        self,
        table_name: str = "agents_config",
        warehouse_id: str | None = None,
        environment: str | None = None,
        domain: str | None = None,
    ):
        self.table_name = table_name      # unused, kept for compat
        self.warehouse_id = warehouse_id  # unused, kept for compat
        self.environment = environment    # when set, only agents with this environment are served
        self.domain = domain              # when set, only agents belonging to this domain are served
        self._w = None  # lazy: WorkspaceClient holds runtime objects that break cloudpickle

    @property
    def w(self):
        """WorkspaceClient — still used for Vector Search and Genie calls."""
        if self._w is None:
            self._w = _build_workspace_client()
        return self._w

    def load(self, agent_id: str) -> dict:
        if not self.domain:
            raise ValueError("AgentConfigLoader requires 'domain' to be set (per-domain schema)")

        row = _api.get_agent(self.domain, agent_id, self.environment)

        if row is None:
            raise ValueError(f"Agent '{agent_id}' not found in agents_config")
        if row.get("tools_enabled") is None:
            row["tools_enabled"] = []
        return row
