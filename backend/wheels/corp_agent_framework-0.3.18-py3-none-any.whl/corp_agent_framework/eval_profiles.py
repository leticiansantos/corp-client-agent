import mlflow


def _build_profiles():
    from mlflow.genai.scorers import Safety, Correctness, RelevanceToQuery, Guidelines
    return {
        "default_internal": [
            Safety(),
            Correctness(),
            RelevanceToQuery(),
        ],
        "support_external": [
            Safety(),
            Correctness(),
            RelevanceToQuery(),
            Guidelines(
                name="business_rules",
                guidelines=[
                    "Não prometa ações fora do catálogo suportado.",
                    "Sempre mencione ID de ticket quando aplicável.",
                ],
            ),
        ],
    }


def run_eval(agent_uri: str, eval_dataset_table: str, profile: str):
    """
    Run MLflow GenAI evaluation for a given agent (model URI) and dataset table.
    """
    from mlflow.genai.datasets import get_dataset

    dataset = get_dataset(name=eval_dataset_table)
    scorers = _build_profiles()[profile]
    return mlflow.genai.evaluate(
        data=dataset,
        model=agent_uri,
        scorers=scorers,
    )
