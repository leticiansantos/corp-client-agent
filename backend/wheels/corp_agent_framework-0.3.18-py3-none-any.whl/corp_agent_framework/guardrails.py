"""
Guardrails system for corp-agent-framework.

Guardrails are interceptors that run at three stages:
  - input:  before the user message reaches the LLM
  - output: before the final response is returned to the user
  - tool:   before a tool call is executed

Each guardrail evaluates content and returns a GuardrailResult indicating
whether the content passed, was blocked, or was sanitized.

Configuration:
  - Global defaults are loaded from the `guardrails_defaults` table in Lakebase.
  - Per-agent overrides come from the `guardrails_config` JSONB column in agents_config.
  - When `disable_defaults` is false (default), agent guardrails are merged with defaults.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Core data structures
# ---------------------------------------------------------------------------

@dataclass
class GuardrailResult:
    passed: bool
    reason: str | None = None
    modified_content: str | None = None


@dataclass
class GuardrailConfig:
    name: str
    action: str = "block"        # block | sanitize | warn | log
    params: dict = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Base class
# ---------------------------------------------------------------------------

class Guardrail:
    """Base class for all guardrails. Subclass and implement `evaluate`."""

    name: str = ""
    stage: str = ""  # "input" | "output" | "tool"

    def evaluate(self, content: str, context: dict) -> GuardrailResult:
        raise NotImplementedError


# ---------------------------------------------------------------------------
# Built-in guardrails
# ---------------------------------------------------------------------------

class PIIDetectorGuardrail(Guardrail):
    """Detects PII patterns: CPF, email, phone numbers, credit card numbers."""

    name = "pii_detector"
    stage = "input"

    _PATTERNS = {
        "cpf": r"\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b",
        "email": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b",
        "phone_br": r"\b(?:\+55\s?)?\(?\d{2}\)?\s?\d{4,5}-?\d{4}\b",
        "credit_card": r"\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b",
    }

    def evaluate(self, content: str, context: dict) -> GuardrailResult:
        detected = []
        for pii_type, pattern in self._PATTERNS.items():
            if re.search(pattern, content):
                detected.append(pii_type)
        if detected:
            return GuardrailResult(
                passed=False,
                reason=f"PII detected: {', '.join(detected)}",
            )
        return GuardrailResult(passed=True)


class PIIScrubberGuardrail(Guardrail):
    """Sanitizes PII from content by replacing with placeholders."""

    name = "pii_scrubber"
    stage = "output"

    _REPLACEMENTS = {
        "cpf": (r"\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b", "[CPF_REDACTED]"),
        "email": (r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b", "[EMAIL_REDACTED]"),
        "phone_br": (r"\b(?:\+55\s?)?\(?\d{2}\)?\s?\d{4,5}-?\d{4}\b", "[PHONE_REDACTED]"),
        "credit_card": (r"\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b", "[CARD_REDACTED]"),
    }

    def evaluate(self, content: str, context: dict) -> GuardrailResult:
        modified = content
        any_match = False
        for _, (pattern, replacement) in self._REPLACEMENTS.items():
            new_content = re.sub(pattern, replacement, modified)
            if new_content != modified:
                any_match = True
                modified = new_content
        if any_match:
            return GuardrailResult(passed=True, modified_content=modified)
        return GuardrailResult(passed=True)


class TopicFilterGuardrail(Guardrail):
    """Blocks messages that don't match allowed topics (keyword-based)."""

    name = "topic_filter"
    stage = "input"

    def evaluate(self, content: str, context: dict) -> GuardrailResult:
        allowed_topics = context.get("params", {}).get("allowed_topics", [])
        if not allowed_topics:
            return GuardrailResult(passed=True)

        content_lower = content.lower()
        for topic in allowed_topics:
            if topic.lower() in content_lower:
                return GuardrailResult(passed=True)

        return GuardrailResult(
            passed=False,
            reason=f"Message does not match allowed topics: {allowed_topics}",
        )


class MaxLengthGuardrail(Guardrail):
    """Blocks or truncates content that exceeds a maximum character length."""

    name = "max_length"
    stage = "input"

    def evaluate(self, content: str, context: dict) -> GuardrailResult:
        max_chars = context.get("params", {}).get("max_chars", 10000)
        if len(content) <= max_chars:
            return GuardrailResult(passed=True)
        action = context.get("action", "block")
        if action == "sanitize":
            return GuardrailResult(
                passed=True,
                modified_content=content[:max_chars],
            )
        return GuardrailResult(
            passed=False,
            reason=f"Content exceeds maximum length of {max_chars} characters ({len(content)}).",
        )


class PromptInjectionGuardrail(Guardrail):
    """Detects common prompt injection patterns."""

    name = "prompt_injection"
    stage = "input"

    _PATTERNS = [
        r"ignore\s+(all\s+)?previous\s+instructions",
        r"ignore\s+(all\s+)?above\s+instructions",
        r"disregard\s+(all\s+)?previous",
        r"you\s+are\s+now\s+(?:a|an)\s+",
        r"forget\s+(all\s+)?your\s+instructions",
        r"new\s+instructions?\s*:",
        r"system\s*:\s*you\s+are",
        r"\[system\]",
        r"<\s*system\s*>",
    ]

    def evaluate(self, content: str, context: dict) -> GuardrailResult:
        content_lower = content.lower()
        for pattern in self._PATTERNS:
            if re.search(pattern, content_lower):
                return GuardrailResult(
                    passed=False,
                    reason="Potential prompt injection detected.",
                )
        return GuardrailResult(passed=True)


# ---------------------------------------------------------------------------
# Generic configurable guardrails (params-driven — no code needed per use case)
# ---------------------------------------------------------------------------

class PatternRedactGuardrail(Guardrail):
    """Redacts content matching a regex pattern. Configured entirely via params.

    params:
      pattern     (str, required) — regex pattern to match
      replacement (str, default "[REDACTED]") — replacement text
      flags       (str, default "") — regex flags: "i" = case-insensitive, "s" = dotall

    Example (salary redaction):
      {"pattern": "R\\\\$\\\\s*[\\\\d.,]+", "replacement": "[SALARIO_REDACTED]"}
    """

    name = "pattern_redact"
    stage = "output"

    def evaluate(self, content: str, context: dict) -> GuardrailResult:
        params = context.get("params", {})
        pattern = params.get("pattern", "")
        if not pattern:
            return GuardrailResult(passed=True)
        replacement = params.get("replacement", "[REDACTED]")
        flags_str = params.get("flags", "")
        flags = 0
        if "i" in flags_str:
            flags |= re.IGNORECASE
        if "s" in flags_str:
            flags |= re.DOTALL
        try:
            modified = re.sub(pattern, replacement, content, flags=flags)
        except re.error:
            return GuardrailResult(passed=True)
        if modified != content:
            return GuardrailResult(passed=True, modified_content=modified)
        return GuardrailResult(passed=True)


class PatternBlockGuardrail(Guardrail):
    """Blocks content if it matches a regex pattern. Configured entirely via params.

    params:
      pattern (str, required) — regex pattern to match
      reason  (str, optional) — custom block reason shown to user
      flags   (str, default "") — regex flags: "i" = case-insensitive

    Example (block SSN mentions):
      {"pattern": "\\\\d{3}-\\\\d{2}-\\\\d{4}", "reason": "SSN não permitido"}
    """

    name = "pattern_block"
    stage = "input"

    def evaluate(self, content: str, context: dict) -> GuardrailResult:
        params = context.get("params", {})
        pattern = params.get("pattern", "")
        if not pattern:
            return GuardrailResult(passed=True)
        flags_str = params.get("flags", "")
        flags = 0
        if "i" in flags_str:
            flags |= re.IGNORECASE
        try:
            if re.search(pattern, content, flags=flags):
                reason = params.get("reason", f"Content matches blocked pattern.")
                return GuardrailResult(passed=False, reason=reason)
        except re.error:
            pass
        return GuardrailResult(passed=True)


class KeywordBlockGuardrail(Guardrail):
    """Blocks content containing any of the specified keywords (case-insensitive).

    params:
      keywords      (list[str], required) — list of terms to block
      match_partial (bool, default true)  — if false, only match whole words
      reason        (str, optional)       — custom block reason

    Example:
      {"keywords": ["senha", "token", "secret"], "match_partial": false}
    """

    name = "keyword_block"
    stage = "input"

    def evaluate(self, content: str, context: dict) -> GuardrailResult:
        params = context.get("params", {})
        keywords = params.get("keywords", [])
        if not keywords:
            return GuardrailResult(passed=True)
        match_partial = params.get("match_partial", True)
        content_lower = content.lower()
        for kw in keywords:
            kw_lower = kw.lower()
            if match_partial:
                found = kw_lower in content_lower
            else:
                found = bool(re.search(r"\b" + re.escape(kw_lower) + r"\b", content_lower))
            if found:
                reason = params.get("reason", f"Termo bloqueado detectado: '{kw}'")
                return GuardrailResult(passed=False, reason=reason)
        return GuardrailResult(passed=True)


class KeywordRedactGuardrail(Guardrail):
    """Replaces specified keywords in output with a placeholder (case-insensitive).

    params:
      keywords    (list[str], required)        — terms to redact
      replacement (str, default "[REDACTED]")  — replacement text

    Example:
      {"keywords": ["salario", "remuneracao"], "replacement": "[VALOR_REDACTED]"}
    """

    name = "keyword_redact"
    stage = "output"

    def evaluate(self, content: str, context: dict) -> GuardrailResult:
        params = context.get("params", {})
        keywords = params.get("keywords", [])
        if not keywords:
            return GuardrailResult(passed=True)
        replacement = params.get("replacement", "[REDACTED]")
        modified = content
        for kw in keywords:
            modified = re.sub(re.escape(kw), replacement, modified, flags=re.IGNORECASE)
        if modified != content:
            return GuardrailResult(passed=True, modified_content=modified)
        return GuardrailResult(passed=True)


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

_BUILTIN_GUARDRAILS: dict[str, type[Guardrail]] = {
    "pii_detector":    PIIDetectorGuardrail,
    "pii_scrubber":    PIIScrubberGuardrail,
    "topic_filter":    TopicFilterGuardrail,
    "max_length":      MaxLengthGuardrail,
    "prompt_injection": PromptInjectionGuardrail,
    # Generic configurable guardrails
    "pattern_redact":  PatternRedactGuardrail,
    "pattern_block":   PatternBlockGuardrail,
    "keyword_block":   KeywordBlockGuardrail,
    "keyword_redact":  KeywordRedactGuardrail,
}


class GuardrailRegistry:
    """Registry of available guardrail implementations."""

    _custom: dict[str, type[Guardrail]] = {}

    @classmethod
    def get(cls, name: str) -> type[Guardrail]:
        if name in cls._custom:
            return cls._custom[name]
        if name in _BUILTIN_GUARDRAILS:
            return _BUILTIN_GUARDRAILS[name]
        raise KeyError(f"Guardrail {name!r} not found in registry")

    @classmethod
    def register(cls, guardrail_cls: type[Guardrail]) -> None:
        cls._custom[guardrail_cls.name] = guardrail_cls

    @classmethod
    def list_guardrails(cls) -> list[str]:
        return list(set(list(_BUILTIN_GUARDRAILS.keys()) + list(cls._custom.keys())))


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

_BLOCKED_RESPONSE = "Sua mensagem foi bloqueada por uma politica de seguranca. Por favor, reformule sua pergunta."


class GuardrailRunner:
    """
    Loads and runs guardrails for a given agent.

    Merges global defaults (from Lakebase or hardcoded fallback) with
    per-agent overrides from agents_config.guardrails_config.
    """

    # Hardcoded fallback defaults used when Lakebase table is unavailable
    DEFAULT_GUARDRAILS: list[dict] = [
        {"stage": "input", "name": "pii_detector", "action": "block", "params": {}, "priority": 0},
        {"stage": "input", "name": "prompt_injection", "action": "block", "params": {}, "priority": 1},
        {"stage": "output", "name": "pii_scrubber", "action": "sanitize", "params": {}, "priority": 0},
    ]

    def __init__(self, agent_config: dict, domain: str | None = None):
        self._guardrails = self._resolve(agent_config, domain)

    def _load_defaults(self, domain: str | None) -> list[dict]:
        """Try loading defaults from corp-client-agent API; fall back to hardcoded."""
        if not domain:
            return list(self.DEFAULT_GUARDRAILS)
        try:
            from . import _api
            rows = _api.get_guardrails(domain)
            if rows:
                return [
                    {
                        "stage": r["stage"],
                        "name": r["name"],
                        "action": r["action"],
                        "params": json.loads(r["params"]) if isinstance(r.get("params"), str) else (r.get("params") or {}),
                        "priority": r.get("priority", 0),
                    }
                    for r in rows
                ]
        except Exception:
            pass
        return list(self.DEFAULT_GUARDRAILS)

    def _resolve(self, agent_config: dict, domain: str | None) -> dict[str, list[GuardrailConfig]]:
        """Merge defaults + agent overrides into a stage-keyed dict."""
        raw_config = agent_config.get("guardrails_config")
        if isinstance(raw_config, str):
            raw_config = json.loads(raw_config)
        raw_config = raw_config or {}

        disable_defaults = raw_config.get("disable_defaults", False)
        defaults = [] if disable_defaults else self._load_defaults(domain)

        merged: dict[str, list[GuardrailConfig]] = {"input": [], "output": [], "tool": []}

        for entry in defaults:
            stage = entry.get("stage", "input")
            if stage in merged:
                merged[stage].append(GuardrailConfig(
                    name=entry["name"],
                    action=entry.get("action", "block"),
                    params=entry.get("params", {}),
                ))

        for stage in ("input", "output", "tool"):
            for entry in raw_config.get(stage, []):
                merged[stage].append(GuardrailConfig(
                    name=entry["name"],
                    action=entry.get("action", "block"),
                    params=entry.get("params", {}),
                ))

        return merged

    def run(self, stage: str, content: str, extra_context: dict | None = None) -> GuardrailResult:
        """
        Run all guardrails for a given stage.

        Returns:
            GuardrailResult with passed=True if all guardrails pass.
            If any guardrail blocks, returns immediately with passed=False.
            If any guardrail sanitizes, the modified content is carried forward.
        """
        configs = self._guardrails.get(stage, [])
        current_content = content

        for cfg in configs:
            try:
                guardrail_cls = GuardrailRegistry.get(cfg.name)
            except KeyError:
                continue

            guardrail = guardrail_cls()
            context = {"action": cfg.action, "params": cfg.params, **(extra_context or {})}
            result = guardrail.evaluate(current_content, context)

            if not result.passed:
                if cfg.action == "block":
                    return GuardrailResult(passed=False, reason=result.reason)
                elif cfg.action == "warn":
                    continue
                elif cfg.action == "log":
                    continue

            if result.modified_content is not None and cfg.action == "sanitize":
                current_content = result.modified_content

        if current_content != content:
            return GuardrailResult(passed=True, modified_content=current_content)
        return GuardrailResult(passed=True)
