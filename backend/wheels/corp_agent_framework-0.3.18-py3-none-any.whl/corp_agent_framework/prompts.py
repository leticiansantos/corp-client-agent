import mlflow
import mlflow.genai
from mlflow.tracking import MlflowClient


def register_prompt(name: str, template: str, alias: str, tags: dict | None = None):
    """
    Register a prompt in the Unity Catalog Prompt Registry and assign an alias.

    Requires an active MLflow experiment with the tag:
        mlflow.promptRegistryLocation = "<catalog>.<schema>"
    pointing to the UC schema where the prompt should be stored.
    """
    prompt = mlflow.genai.register_prompt(
        name=name,
        template=template,
        commit_message=f"Initial version for {name}",
        tags=tags or {},
    )
    mlflow.genai.set_prompt_alias(name=name, alias=alias, version=prompt.version)
    return prompt


def load_prompt(name: str, alias: str) -> str:
    """
    Load a prompt template from the Unity Catalog Prompt Registry given a name and alias.

    Uses MlflowClient.get_prompt_version_by_alias to resolve the alias without
    depending on an active MLflow experiment context (required in serving containers).
    """
    client = MlflowClient(tracking_uri="databricks")
    version = client.get_prompt_version_by_alias(name=name, alias=alias)
    return version.template
