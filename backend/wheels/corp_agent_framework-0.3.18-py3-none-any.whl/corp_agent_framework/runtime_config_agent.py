import json
import time
from typing import Iterator

import mlflow
from mlflow.types.responses import (
    ResponseCompletedEvent,
    ResponseTextDeltaEvent,
    ResponsesAgentRequest,
    ResponsesAgentResponse,
    ResponsesAgentStreamEvent,
)

from .base_agent import CorpAgent, _SafeSpan
from .config_loader import AgentConfigLoader
from .guardrails import GuardrailRunner, _BLOCKED_RESPONSE
from .prompts import load_prompt
from .tool_config_loader import ToolConfigLoader
from .tools import ToolSpec

_MAX_TOOL_ITERATIONS = 5

# Models that support the Responses API passthrough on Databricks AI Gateway.
# Everything else (Claude, Llama, Mistral, …) uses Chat Completions.
_RESPONSES_API_PREFIXES = ("gpt-", "o1-", "o3-", "o4-")


def _use_chat_completions(model: str) -> bool:
    return not any(model.startswith(p) for p in _RESPONSES_API_PREFIXES)


class ConfigDrivenAgent(CorpAgent):
    """
    Config-driven agent runtime.

    At request time:
      1. Reads agent config from UC (agents_config) using agent_id from custom_inputs.
      2. Loads system prompt from Prompt Registry.
      3. Resolves enabled tools from ToolRegistry and builds tool definitions:
           - mcp_vector_search  → client-side VS query (Chat Completions) or MCP (Responses)
           - mcp_genie          → client-side Genie query (Chat Completions) or MCP (Responses)
           - uc_function        → UCFunctionToolkit (client-side execution)
           - agent_call         → Python call to _run_agent (client-side)
           - skill              → Python-only, called outside LLM loop
      4. Runs an agentic loop: LLM call → tool execution → repeat until final text response.
         Uses Chat Completions API for Claude/Llama/etc., Responses API for OpenAI GPT models.
      5. Every step is traced via MLflow Tracing.
    """

    def __init__(
        self,
        config_table: str = "main.agents_config",
        tools_table: str = "main.agents.tools_config",
        warehouse_id: str | None = None,
        environment: str | None = None,
        domain: str | None = None,
    ):
        super().__init__(name="config_driven_agent")
        self.loader = AgentConfigLoader(
            table_name=config_table,
            warehouse_id=warehouse_id,
            environment=environment,
            domain=domain,
        )
        self.tool_loader = ToolConfigLoader(table_name=tools_table, warehouse_id=warehouse_id)
        self._domain = domain
        self._llm = None  # lazy: initialized on first inference call, not at log_model time

    @property
    def llm(self):
        if self._llm is None:
            from databricks_openai import DatabricksOpenAI
            self._llm = DatabricksOpenAI()
        return self._llm

    def _run_agent(self, request: ResponsesAgentRequest) -> ResponsesAgentResponse:
        agent_id = (request.custom_inputs or {}).get("agent_id")
        if not agent_id:
            return ResponsesAgentResponse(output=[{
                "id": "error-0",
                "type": "message",
                "role": "assistant",
                "content": [{"type": "output_text", "text": "Error: 'agent_id' is required in custom_inputs."}],
            }])

        with _SafeSpan(name=f"config_driven:{agent_id}", span_type="AGENT") as span:
            span.set_inputs({"agent_id": agent_id, "messages": request.input or []})

            cfg = self.loader.load(agent_id)
            guardrails = GuardrailRunner(cfg, domain=self._domain)

            # --- Input guardrails ---
            user_text = self._extract_user_text(request.input)
            if user_text:
                with _SafeSpan(name="guardrails:input", span_type="GUARDRAIL") as gr_span:
                    gr_result = guardrails.run("input", user_text)
                    gr_span.set_outputs({"passed": gr_result.passed, "reason": gr_result.reason})
                    if not gr_result.passed:
                        span.set_outputs({"blocked_by": "input_guardrail", "reason": gr_result.reason})
                        return self._blocked_response(gr_result.reason)

            prompt_name = cfg.get("prompt_name")
            prompt_alias = cfg.get("prompt_alias") or "dev"
            prompt_template = load_prompt(prompt_name, prompt_alias) if prompt_name else ""

            tools_enabled = cfg.get("tools_enabled") or []
            tool_specs = self.tool_loader.load_many(tools_enabled, environment=cfg.get("environment"), domain=self._domain) if tools_enabled else []

            system_prompt = self._build_system_prompt(prompt_template, cfg)
            model = cfg.get("model") or "databricks-claude-sonnet-4-6"

            if _use_chat_completions(model):
                tools_cc, uc_toolkit, vs_map, genie_map, agent_call_map = self._build_tools_cc(tool_specs)
                messages = [{"role": "system", "content": system_prompt}] + self._to_cc_messages(request.input)
                text = self._agentic_loop_cc(messages, tools_cc, uc_toolkit, vs_map, genie_map, agent_call_map, model)
            else:
                api_tools, uc_toolkit, agent_call_map = self._build_tools_responses(tool_specs)
                messages = [{"role": "system", "content": system_prompt}] + list(request.input or [])
                text = self._agentic_loop_responses(messages, api_tools, uc_toolkit, model, agent_call_map)

            # --- Output guardrails ---
            with _SafeSpan(name="guardrails:output", span_type="GUARDRAIL") as gr_span:
                gr_result = guardrails.run("output", text)
                gr_span.set_outputs({"passed": gr_result.passed, "modified": gr_result.modified_content is not None})
                if not gr_result.passed:
                    text = _BLOCKED_RESPONSE
                elif gr_result.modified_content is not None:
                    text = gr_result.modified_content

            result = ResponsesAgentResponse(
                output=[{
                    "id": "out-1",
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": text}],
                }]
            )
            span.set_outputs({"response": text})
            return result

    # ------------------------------------------------------------------
    # Streaming predict
    # ------------------------------------------------------------------

    def predict_stream(
        self, request: ResponsesAgentRequest
    ) -> Iterator[ResponsesAgentStreamEvent]:
        """
        Streaming version: emits a status message when each tool starts executing,
        then streams the final answer text, and closes with ResponseCompletedEvent.
        """
        item_id = "out-stream-1"
        accumulated = []

        for event in self._run_agent_stream(request, item_id):
            if isinstance(event, ResponseTextDeltaEvent):
                accumulated.append(event.delta)
            yield event

        full_text = "".join(accumulated)
        yield ResponseCompletedEvent(
            response=ResponsesAgentResponse(
                output=[{
                    "id": item_id,
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": full_text}],
                }]
            )
        )

    def _run_agent_stream(
        self, request: ResponsesAgentRequest, item_id: str
    ) -> Iterator[ResponsesAgentStreamEvent]:
        agent_id = (request.custom_inputs or {}).get("agent_id")
        if not agent_id:
            yield ResponseTextDeltaEvent(
                item_id=item_id,
                delta="Erro: 'agent_id' é obrigatório em custom_inputs.",
            )
            return

        cfg = self.loader.load(agent_id)
        guardrails = GuardrailRunner(cfg, domain=self._domain)

        # --- Input guardrails ---
        user_text = self._extract_user_text(request.input)
        if user_text:
            gr_result = guardrails.run("input", user_text)
            if not gr_result.passed:
                yield ResponseTextDeltaEvent(item_id=item_id, delta=_BLOCKED_RESPONSE)
                return

        prompt_name = cfg.get("prompt_name")
        prompt_alias = cfg.get("prompt_alias") or "dev"
        prompt_template = load_prompt(prompt_name, prompt_alias) if prompt_name else ""

        tools_enabled = cfg.get("tools_enabled") or []
        tool_specs = (
            self.tool_loader.load_many(
                tools_enabled,
                environment=cfg.get("environment"),
                domain=self._domain,
            )
            if tools_enabled
            else []
        )

        system_prompt = self._build_system_prompt(prompt_template, cfg)
        model = cfg.get("model") or "databricks-claude-sonnet-4-6"

        if _use_chat_completions(model):
            tools_cc, uc_toolkit, vs_map, genie_map, agent_call_map = self._build_tools_cc(tool_specs)
            messages = [{"role": "system", "content": system_prompt}] + self._to_cc_messages(request.input)
            # Collect streamed text for output guardrails
            collected = []
            for event in self._agentic_loop_cc_stream(
                messages, tools_cc, uc_toolkit, vs_map, genie_map, agent_call_map, model, item_id
            ):
                if isinstance(event, ResponseTextDeltaEvent):
                    collected.append(event.delta)
                else:
                    yield event

            full_text = "".join(collected)
            gr_result = guardrails.run("output", full_text)
            if not gr_result.passed:
                yield ResponseTextDeltaEvent(item_id=item_id, delta=_BLOCKED_RESPONSE)
            elif gr_result.modified_content is not None:
                yield ResponseTextDeltaEvent(item_id=item_id, delta=gr_result.modified_content)
            else:
                yield ResponseTextDeltaEvent(item_id=item_id, delta=full_text)
        else:
            api_tools, uc_toolkit, agent_call_map = self._build_tools_responses(tool_specs)
            messages = [{"role": "system", "content": system_prompt}] + list(request.input or [])
            text = self._agentic_loop_responses(messages, api_tools, uc_toolkit, model, agent_call_map)

            # --- Output guardrails ---
            gr_result = guardrails.run("output", text)
            if not gr_result.passed:
                text = _BLOCKED_RESPONSE
            elif gr_result.modified_content is not None:
                text = gr_result.modified_content
            yield ResponseTextDeltaEvent(item_id=item_id, delta=text)

    def _tool_status(self, name: str, vs_map: dict, genie_map: dict, agent_call_map: dict) -> str:
        if name in vs_map:
            return f"Pesquisando na base de conhecimento ({name})...\n"
        if name in genie_map:
            return f"Consultando Genie ({name})...\n"
        if agent_call_map and name in agent_call_map:
            return f"Consultando agente ({name})...\n"
        return f"Executando ferramenta ({name})...\n"

    def _agentic_loop_cc_stream(
        self,
        messages: list[dict],
        tools_cc: list[dict],
        uc_toolkit: object,
        vs_map: dict[str, str],
        genie_map: dict[str, str],
        agent_call_map: dict[str, str] | None,
        model: str,
        item_id: str,
    ) -> Iterator[ResponsesAgentStreamEvent]:
        for _ in range(_MAX_TOOL_ITERATIONS):
            kwargs: dict = {"model": model, "messages": messages}
            if tools_cc:
                kwargs["tools"] = tools_cc

            response = self.llm.chat.completions.create(**kwargs)
            msg = response.choices[0].message
            tool_calls = getattr(msg, "tool_calls", None) or []

            if not tool_calls:
                yield ResponseTextDeltaEvent(item_id=item_id, delta=msg.content or "")
                return

            messages = messages + [msg]
            tool_results: list[dict] = []

            for tc in tool_calls:
                name = tc.function.name
                raw_args = tc.function.arguments
                args = json.loads(raw_args) if isinstance(raw_args, str) else (raw_args or {})

                yield ResponseTextDeltaEvent(
                    item_id=item_id,
                    delta=self._tool_status(name, vs_map, genie_map, agent_call_map or {}),
                )

                try:
                    if name in vs_map:
                        result = self._exec_vector_search(vs_map[name], args.get("query", str(args)))
                    elif name in genie_map:
                        result = self._exec_genie(genie_map[name], args.get("question", str(args)))
                    elif agent_call_map and name in agent_call_map:
                        result = self._call_sub_agent(agent_call_map[name], args.get("message", str(args)))
                    elif uc_toolkit:
                        result = uc_toolkit.execute(name, args)
                    else:
                        result = {"error": f"No handler for tool {name}"}
                except Exception as e:
                    result = {"error": str(e)}

                tool_results.append({
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": json.dumps(result) if not isinstance(result, str) else result,
                })

            messages = messages + tool_results

        yield ResponseTextDeltaEvent(
            item_id=item_id, delta="[Limite de iterações de ferramentas atingido]"
        )

    # ------------------------------------------------------------------
    # Input conversion
    # ------------------------------------------------------------------

    def _to_cc_messages(self, input_items) -> list[dict]:
        """Convert ResponsesAgentRequest.input to Chat Completions messages."""
        result = []
        for m in (input_items or []):
            if isinstance(m, dict):
                result.append({"role": m.get("role", "user"), "content": m.get("content", "")})
            else:
                content = getattr(m, "content", "")
                if isinstance(content, list):
                    text = next(
                        (getattr(c, "text", str(c)) for c in content),
                        "",
                    )
                else:
                    text = str(content) if content else ""
                result.append({"role": getattr(m, "role", "user"), "content": text})
        return result

    # ------------------------------------------------------------------
    # Tool resolution — Chat Completions (Claude, Llama, …)
    # ------------------------------------------------------------------

    def _build_tools_cc(
        self, tool_specs: list[ToolSpec]
    ) -> tuple[list[dict], object, dict, dict, dict]:
        """
        Build tools in Chat Completions format.

        Returns:
            tools_cc:       list of tool dicts for chat.completions.create(tools=...)
            uc_toolkit:     UCFunctionToolkit instance (or None)
            vs_map:         {tool_name: index_name}  — vector search tools
            genie_map:      {tool_name: space_id}    — genie tools
            agent_call_map: {tool_name: agent_id}    — sub-agent tools
        """
        tools_cc: list[dict] = []
        uc_function_names: list[str] = []
        vs_map: dict[str, str] = {}
        genie_map: dict[str, str] = {}
        agent_call_map: dict[str, str] = {}

        for spec in tool_specs:
            if spec.kind == "mcp_vector_search":
                # Extract index name from MCP URL: .../vector-search/<catalog.schema.index>
                index_name = spec.ref.split("/vector-search/")[-1]
                vs_map[spec.name] = index_name
                tools_cc.append({
                    "type": "function",
                    "function": {
                        "name": spec.name,
                        "description": spec.description or "Search for relevant documents.",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "query": {"type": "string", "description": "Search query text"},
                            },
                            "required": ["query"],
                        },
                    },
                })
            elif spec.kind == "mcp_genie":
                # Extract space ID from MCP URL: .../genie/<space_id>
                space_id = spec.ref.split("/genie/")[-1]
                genie_map[spec.name] = space_id
                tools_cc.append({
                    "type": "function",
                    "function": {
                        "name": spec.name,
                        "description": spec.description or "Query data using natural language.",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "question": {"type": "string", "description": "Natural language question"},
                            },
                            "required": ["question"],
                        },
                    },
                })
            elif spec.kind == "uc_function":
                uc_function_names.append(spec.ref)
            elif spec.kind == "agent_call":
                agent_call_map[spec.name] = spec.ref
                tools_cc.append({
                    "type": "function",
                    "function": {
                        "name": spec.name,
                        "description": spec.description or f"Delegates to sub-agent '{spec.ref}'",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "message": {"type": "string", "description": "Message to forward to the sub-agent"},
                            },
                            "required": ["message"],
                        },
                    },
                })
            # "skill" kind: Python-only callables, invoked outside the LLM loop

        uc_toolkit = None
        if uc_function_names:
            from databricks_openai import UCFunctionToolkit
            uc_toolkit = UCFunctionToolkit(function_names=uc_function_names)
            tools_cc.extend(uc_toolkit.tools)

        return tools_cc, uc_toolkit, vs_map, genie_map, agent_call_map

    # ------------------------------------------------------------------
    # Tool resolution — Responses API (OpenAI GPT models)
    # ------------------------------------------------------------------

    def _build_tools_responses(self, tool_specs: list[ToolSpec]) -> tuple[list[dict], object, dict[str, str]]:
        """Build tools in Responses API format (MCP + UCFunctionToolkit)."""
        api_tools: list[dict] = []
        uc_function_names: list[str] = []
        agent_call_map: dict[str, str] = {}

        for spec in tool_specs:
            if spec.kind in ("mcp_vector_search", "mcp_genie", "external_mcp"):
                api_tools.append({
                    "type": "mcp",
                    "server_label": spec.name,
                    "server_url": spec.ref,
                    "require_approval": "never",
                })
            elif spec.kind == "uc_function":
                uc_function_names.append(spec.ref)
            elif spec.kind == "agent_call":
                agent_call_map[spec.name] = spec.ref
                api_tools.append({
                    "type": "function",
                    "name": spec.name,
                    "description": spec.description or f"Delegates to sub-agent '{spec.ref}'",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "message": {"type": "string", "description": "Message to forward to the sub-agent"},
                        },
                        "required": ["message"],
                    },
                })

        uc_toolkit = None
        if uc_function_names:
            from databricks_openai import UCFunctionToolkit
            uc_toolkit = UCFunctionToolkit(function_names=uc_function_names)
            api_tools.extend(uc_toolkit.tools)

        return api_tools, uc_toolkit, agent_call_map

    # ------------------------------------------------------------------
    # Agentic loop — Chat Completions API
    # ------------------------------------------------------------------

    def _agentic_loop_cc(
        self,
        messages: list[dict],
        tools_cc: list[dict],
        uc_toolkit: object,
        vs_map: dict[str, str],
        genie_map: dict[str, str],
        agent_call_map: dict[str, str] | None,
        model: str,
    ) -> str:
        for iteration in range(_MAX_TOOL_ITERATIONS):
            kwargs: dict = {"model": model, "messages": messages}
            if tools_cc:
                kwargs["tools"] = tools_cc

            with _SafeSpan(name=f"llm_call_{iteration}", span_type="LLM") as llm_span:
                llm_span.set_inputs({"model": model, "n_messages": len(messages), "n_tools": len(tools_cc)})
                response = self.llm.chat.completions.create(**kwargs)
                msg = response.choices[0].message
                llm_span.set_outputs({"finish_reason": response.choices[0].finish_reason})

            tool_calls = getattr(msg, "tool_calls", None) or []
            if not tool_calls:
                return msg.content or ""

            # Append assistant message (with tool_calls) to history
            messages = messages + [msg]

            # Execute each tool call client-side
            tool_results: list[dict] = []
            for tc in tool_calls:
                name = tc.function.name
                raw_args = tc.function.arguments
                args = json.loads(raw_args) if isinstance(raw_args, str) else (raw_args or {})

                with _SafeSpan(name=f"tool:{name}", span_type="TOOL") as tool_span:
                    tool_span.set_inputs({"name": name, "arguments": args})
                    try:
                        if name in vs_map:
                            result = self._exec_vector_search(vs_map[name], args.get("query", str(args)))
                        elif name in genie_map:
                            result = self._exec_genie(genie_map[name], args.get("question", str(args)))
                        elif agent_call_map and name in agent_call_map:
                            result = self._call_sub_agent(agent_call_map[name], args.get("message", str(args)))
                        elif uc_toolkit:
                            result = uc_toolkit.execute(name, args)
                        else:
                            result = {"error": f"No handler for tool {name}"}
                    except Exception as e:
                        result = {"error": str(e)}
                    tool_span.set_outputs({"result": str(result)[:500]})

                tool_results.append({
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": json.dumps(result) if not isinstance(result, str) else result,
                })

            messages = messages + tool_results

        return "[Limite de iterações de ferramentas atingido]"

    # ------------------------------------------------------------------
    # Agentic loop — Responses API (OpenAI GPT only)
    # ------------------------------------------------------------------

    def _agentic_loop_responses(
        self,
        messages: list[dict],
        api_tools: list[dict],
        uc_toolkit: object,
        model: str,
        agent_call_map: dict[str, str] | None = None,
    ) -> str:
        for iteration in range(_MAX_TOOL_ITERATIONS):
            kwargs: dict = {"model": model, "input": messages}
            if api_tools:
                kwargs["tools"] = api_tools

            with _SafeSpan(name=f"llm_call_{iteration}", span_type="LLM") as llm_span:
                llm_span.set_inputs({"model": model, "n_messages": len(messages), "n_tools": len(api_tools)})
                response = self.llm.responses.create(**kwargs)
                output_types = [getattr(item, "type", "unknown") for item in response.output]
                llm_span.set_outputs({"output_types": output_types})

            function_calls = [
                item for item in response.output
                if getattr(item, "type", "") == "function_call"
            ]

            if not function_calls:
                for item in response.output:
                    if getattr(item, "type", "") == "message":
                        content = getattr(item, "content", [])
                        if content:
                            return content[0].text
                return ""

            tool_results: list[dict] = []
            for call in function_calls:
                with _SafeSpan(name=f"tool:{call.name}", span_type="TOOL") as tool_span:
                    tool_span.set_inputs({"name": call.name, "arguments": call.arguments})
                    try:
                        args = json.loads(call.arguments) if isinstance(call.arguments, str) else call.arguments
                        if agent_call_map and call.name in agent_call_map:
                            result = self._call_sub_agent(agent_call_map[call.name], args.get("message", str(args)))
                        elif uc_toolkit:
                            result = uc_toolkit.execute(call.name, args)
                        else:
                            result = {"error": f"No handler for tool {call.name}"}
                    except Exception as e:
                        result = {"error": str(e)}
                    tool_span.set_outputs({"result": str(result)})

                tool_results.append({
                    "type": "function_result",
                    "call_id": call.call_id,
                    "output": json.dumps(result) if not isinstance(result, str) else result,
                })

            messages = messages + [{"role": "assistant", "content": response.output}] + tool_results

        return "[Limite de iterações de ferramentas atingido]"

    # ------------------------------------------------------------------
    # Client-side tool executors
    # ------------------------------------------------------------------

    def _vs_columns(self, w, index_name: str) -> list[str]:
        """Discover columns for a VS index from its source table (cached per instance)."""
        if not hasattr(self, "_vs_col_cache"):
            self._vs_col_cache: dict[str, list[str]] = {}
        if index_name not in self._vs_col_cache:
            try:
                idx = w.vector_search_indexes.get_index(index_name=index_name)
                spec = getattr(idx, "delta_sync_index_spec", None)
                src = getattr(spec, "source_table", None) if spec else None
                if src:
                    tbl = w.tables.get(src)
                    self._vs_col_cache[index_name] = [c.name for c in tbl.columns]
                else:
                    self._vs_col_cache[index_name] = ["id", "content", "title"]
            except Exception:
                self._vs_col_cache[index_name] = ["id", "content", "title"]
        return self._vs_col_cache[index_name]

    def _exec_vector_search(self, index_name: str, query: str) -> str:
        """Query a Databricks Vector Search index via SDK."""
        try:
            w = self.loader.w
            columns = self._vs_columns(w, index_name)
            resp = w.vector_search_indexes.query_index(
                index_name=index_name,
                columns=columns,
                query_text=query,
                num_results=5,
            )
            rows = (resp.result and resp.result.data_array) or []
            cols = [c.name for c in (resp.manifest and resp.manifest.columns) or []]
            if not rows:
                return "Nenhum documento encontrado para esta consulta."
            docs = []
            for row in rows:
                d = dict(zip(cols, row))
                text = (d.get("content") or d.get("chunk_text") or
                        d.get("text") or d.get("page_content") or str(d))
                title = d.get("title") or d.get("source") or d.get("url") or ""
                docs.append(f"{text}\n[fonte: {title}]" if title else text)
            return "\n\n---\n\n".join(docs)
        except Exception as e:
            return f"Erro na busca vetorial [{index_name}]: {type(e).__name__}: {e}"

    def _exec_genie(self, space_id: str, question: str) -> str:
        """Query a Genie space via REST API and execute the generated SQL."""
        try:
            import requests as _requests
            w = self.loader.w
            host = (w.config.host or "").rstrip("/")
            token = w.config.token
            headers = {
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            }

            # Start conversation
            resp = _requests.post(
                f"{host}/api/2.0/genie/spaces/{space_id}/start-conversation",
                headers=headers,
                json={"content": question},
                timeout=30,
            )
            resp.raise_for_status()
            data = resp.json()
            conv_id = data["conversation_id"]
            msg_id = data["message_id"]

            # Poll until completed
            for _ in range(60):
                poll = _requests.get(
                    f"{host}/api/2.0/genie/spaces/{space_id}/conversations/{conv_id}/messages/{msg_id}",
                    headers=headers,
                    timeout=15,
                )
                poll.raise_for_status()
                msg = poll.json()
                status = msg.get("status", "")
                if status == "COMPLETED":
                    for att in msg.get("attachments", []):
                        if "text" in att:
                            return att["text"].get("content", "")
                        if "query" in att:
                            sql = att["query"].get("query", "")
                            if sql and self.tool_loader.warehouse_id:
                                exec_resp = w.statement_execution.execute_statement(
                                    warehouse_id=self.tool_loader.warehouse_id,
                                    statement=sql,
                                    wait_timeout="30s",
                                )
                                da = exec_resp.result and exec_resp.result.data_array
                                if da:
                                    cols2 = [c.name for c in exec_resp.manifest.schema.columns]
                                    rows = [dict(zip(cols2, r)) for r in da[:10]]
                                    return json.dumps(rows, ensure_ascii=False)
                    return "Genie retornou resultado vazio."
                elif status in ("FAILED", "CANCELLED"):
                    return f"Genie falhou: {msg.get('error', status)}"
                time.sleep(1)

            return "Genie: timeout aguardando resposta."
        except Exception as e:
            return f"Erro no Genie: {e}"

    # ------------------------------------------------------------------
    # Sub-agent call (agent_call tool kind)
    # ------------------------------------------------------------------

    def _call_sub_agent(self, agent_id: str, message: str) -> str:
        """
        Invoke another agent running in the same endpoint by calling _run_agent
        directly — no HTTP overhead, shares the same AgentConfigLoader and LLM client.
        """
        sub_request = ResponsesAgentRequest(
            input=[{"role": "user", "content": message}],
            custom_inputs={"agent_id": agent_id},
        )
        with _SafeSpan(name=f"sub_agent:{agent_id}", span_type="AGENT") as span:
            span.set_inputs({"agent_id": agent_id, "message": message})
            sub_response = self._run_agent(sub_request)
            for item in sub_response.output:
                item_type = item.get("type") if isinstance(item, dict) else getattr(item, "type", "")
                if item_type == "message":
                    content = item.get("content", []) if isinstance(item, dict) else getattr(item, "content", [])
                    if content:
                        c = content[0]
                        text = c.get("text", "") if isinstance(c, dict) else getattr(c, "text", "")
                        span.set_outputs({"result": text})
                        return text
            span.set_outputs({"result": ""})
            return ""

    # ------------------------------------------------------------------
    # Prompt assembly
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Guardrail helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_user_text(input_items) -> str:
        """Extract the last user message text for guardrail evaluation."""
        for m in reversed(list(input_items or [])):
            if isinstance(m, dict):
                if m.get("role") == "user":
                    content = m.get("content", "")
                    if isinstance(content, str):
                        return content
                    if isinstance(content, list):
                        return " ".join(
                            c.get("text", str(c)) if isinstance(c, dict) else str(c)
                            for c in content
                        )
            else:
                if getattr(m, "role", "") == "user":
                    content = getattr(m, "content", "")
                    if isinstance(content, str):
                        return content
                    if isinstance(content, list):
                        return " ".join(
                            getattr(c, "text", str(c)) for c in content
                        )
        return ""

    @staticmethod
    def _blocked_response(reason: str | None = None) -> ResponsesAgentResponse:
        return ResponsesAgentResponse(
            output=[{
                "id": "blocked-0",
                "type": "message",
                "role": "assistant",
                "content": [{"type": "output_text", "text": _BLOCKED_RESPONSE}],
            }]
        )

    def _build_system_prompt(self, prompt_template: str, cfg: dict) -> str:
        return prompt_template or "You are a helpful assistant."
