from .tools import ToolSpec
from . import _api


class ToolConfigLoader:
    """
    Loads tool specifications from corp-client-agent HTTP API.
    Requires CORP_CLIENT_AGENT_URL env var set to the app's base URL.
    warehouse_id is still used by ConfigDrivenAgent for Genie SQL execution.
    """

    def __init__(self, table_name: str = "tools_config", warehouse_id: str | None = None):
        self.table_name = table_name      # unused, kept for compat
        self.warehouse_id = warehouse_id  # still used by Genie executor for SQL

    def load_many(self, tool_names: list[str], environment: str | None = None, domain: str | None = None) -> list[ToolSpec]:
        """Load active ToolSpecs for the given tool names from the domain's schema."""
        if not tool_names:
            return []
        if not domain:
            raise ValueError("ToolConfigLoader.load_many requires 'domain' (per-domain schema)")

        rows = _api.get_tools(domain, tool_names, environment)

        if not rows:
            raise ValueError(
                f"No active tools found for: {set(tool_names)}. "
                f"Check that tools exist in tools_config with status='active'."
            )
        loaded = {r["tool_name"] for r in rows}
        missing = set(tool_names) - loaded
        if missing:
            raise ValueError(f"Tools not found or not active: {missing}.")
        return [
            ToolSpec(
                name=r["tool_name"],
                kind=r["kind"],
                ref=r["ref"],
                description=r.get("description"),
            )
            for r in rows
        ]
