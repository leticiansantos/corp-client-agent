from dataclasses import dataclass


@dataclass
class ToolSpec:
    name: str
    kind: str   # "mcp_vector_search" | "mcp_genie" | "uc_function" | "external_mcp" | "skill" | "agent_call"
    ref: str    # MCP URL, UC function name, or agent_id (for agent_call)
    description: str | None = None  # used as LLM tool description for agent_call kind


class ToolRegistry:
    """
    Central registry for approved tools (Vector Search, Genie, UC functions, external MCP).
    The runtime uses these definitions to bind tools for a given agent.
    """

    _TOOLS: dict[str, ToolSpec] = {}

    @classmethod
    def get(cls, name: str) -> ToolSpec:
        if name not in cls._TOOLS:
            raise KeyError(f"Tool {name!r} not found in registry")
        return cls._TOOLS[name]

    @classmethod
    def register(cls, spec: ToolSpec) -> None:
        cls._TOOLS[spec.name] = spec

    @classmethod
    def list_tools(cls) -> list[str]:
        return list(cls._TOOLS.keys())
